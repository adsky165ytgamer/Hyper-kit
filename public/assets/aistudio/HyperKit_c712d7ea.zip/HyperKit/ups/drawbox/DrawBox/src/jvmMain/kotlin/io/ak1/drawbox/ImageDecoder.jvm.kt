package io.ak1.drawbox

import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.toComposeImageBitmap
import org.jetbrains.skia.Image

actual fun decodeImageBitmap(bytes: ByteArray): ImageBitmap? = runCatching {
    Image.makeFromEncoded(bytes).toComposeImageBitmap()
}.getOrNull()

actual fun decodeImageBitmapDownsampled(
    bytes: ByteArray,
    targetWidth: Int,
    targetHeight: Int,
): ImageBitmap? = decodeAndDownsampleSkia(bytes, targetWidth, targetHeight)

/**
 * Shared skia helper: decode at source resolution, then draw scaled into a
 * smaller [org.jetbrains.skia.Surface]. The source bitmap is short-lived
 * (one frame's allocation) — the cache stores only the downsampled output.
 *
 * Duplicated across `jvmMain`, `iosMain`, and `wasmJsMain` to avoid a
 * skia-shared intermediate source set (which needs custom KMP hierarchy
 * config). Consolidate once the SDK introduces a `skikoMain`-style
 * intermediate.
 */
private fun decodeAndDownsampleSkia(
    bytes: ByteArray,
    targetWidth: Int,
    targetHeight: Int,
): ImageBitmap? = runCatching {
    val src = org.jetbrains.skia.Image.makeFromEncoded(bytes)
    val srcW = src.width.coerceAtLeast(1)
    val srcH = src.height.coerceAtLeast(1)
    val capW = targetWidth.coerceAtLeast(1)
    val capH = targetHeight.coerceAtLeast(1)
    val scale = minOf(capW.toFloat() / srcW, capH.toFloat() / srcH)
    if (scale >= 1f) {
        // Don't upscale — return source-resolution bitmap.
        return@runCatching src.toComposeImageBitmap()
    }
    val outW = (srcW * scale).toInt().coerceAtLeast(1)
    val outH = (srcH * scale).toInt().coerceAtLeast(1)
    val surface = org.jetbrains.skia.Surface.makeRasterN32Premul(outW, outH)
    surface.canvas.drawImageRect(
        src,
        org.jetbrains.skia.Rect(0f, 0f, srcW.toFloat(), srcH.toFloat()),
        org.jetbrains.skia.Rect(0f, 0f, outW.toFloat(), outH.toFloat()),
    )
    surface.makeImageSnapshot().toComposeImageBitmap()
}.getOrNull()
